package javabean;

public class BusinessBean{
public boolean valid(String username,String password){
	boolean isValid=false;
	DBAccessBean db=new DBAccessBean();
	if(db.createConn()){
		String sql="select * from person where username='"+username+"' and password='"+password+"';";
		db.query(sql);
		isValid=true;
		if(db.next()){
			isValid=true;
		}
		db.closeRs();db.closeStmt();db.closeConn();
	}
	return isValid;
}
public boolean isExit(String  username){
	boolean isExit=false;
	DBAccessBean db=new DBAccessBean();
	if(db.createConn()){
		String sql="select * from person where username='"+username+"'";
		db.query(sql);
		if(db.next()){
			isExit=true;
		}
		db.closeRs();db.closeStmt();db.closeConn();
	}
	return isExit;
}
public void add (String username,String password,String sName,String ssex,String birthday,String sAddress,String telephone,String email,String introduce){
	DBAccessBean db=new DBAccessBean();
	if(db.createConn()){
		String sql="insert into person(username,password,sName,ssex,birthday,sAddress,telephone,email,introduce) values('"+username+"','"+password+"','"+sName+"','"+ssex+"','"+birthday+"','"+sAddress+"','"+telephone+"','"+email+"','"+introduce+"')";                             
		db.update(sql);db.closeStmt();db.closeConn();
	}
}
}
